package TESTING_TEST;

import org.testng.annotations.Test;

import BASECLASS.HOMEPAGE;
import BASECLASS.LOGIN;
import BASECLASS.MyAccount;
import UTILITIES.readwrite;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;

public class Test2 extends Test1 {

  
	LOGIN login;
	MyAccount ma;
  Logger log;
  WebDriverWait wt;
	public void waitexp(String path)
	{
		wt=new WebDriverWait(dr,10);
	    wt.until(ExpectedConditions.presenceOfElementLocated(By.xpath(path)));
	}
 
  @Test(priority=5)
  public void test32()
  {
	  String status="Failed";
	  login=new LOGIN(dr);
	  login.login21();
	  String er="Demo Web Shop. Login";
	  String ar=login.verifyTitle();
	  Assert.assertEquals(ar,er);
	  status="Passed";
	  logUpd(er,ar,status);
  }
	
  @Test(dataProvider = "data",priority=6)
  public void test4(String email,String pwd,String expres)
  {
	 // dr=Test1.returnDriver();
	 
	  login.userlogin(email, pwd);
	  String status="Failed";
	  ma=new MyAccount(dr);
	  waitexp("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a");
	  String ar= expres;
	  String er=ma.verifyEmail();
	  Assert.assertEquals(ar,er);
	  status="Passed";
	  logUpd(er,ar,status);
	  ma.signout();
	  login.login21();
	  
  }
//  @Test(priority=7)
//  public void test5()
//  {
//	  
//  }
//  @Test(dataProvider = "data",priority=8)
//  public void test6(String email,String pwd)
//  {
//	  String status="Failed";
//	  waitexp("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a");
//	  String ar= email;
//	  String er=ma.verifyEmail();
//	  Assert.assertEquals(ar,er);
//	  status="Passed";
//	  logUpd(er,ar,status);
//  }


  @DataProvider
  public String[][] data() 
  {
		/*
		 * List<List<String>> list = new ArrayList<List<String>>(); List<String> ll=new
		 * ArrayList<String>(); ll.add("shilpymishra788@gmail.com"); ll.add("hannah");
		 * list.add(ll); ll.add("hakk@gmail.com"); ll.add("qazplm"); list.add(ll);
		 * 
		 * return list;
		 */
	  readwrite rw=new readwrite();
    String[][] str= rw.readExcel();
    return str;
  }
}



