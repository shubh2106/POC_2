package UTILITIES;

public class Per_Details {
String email,pwd,expres;
}
