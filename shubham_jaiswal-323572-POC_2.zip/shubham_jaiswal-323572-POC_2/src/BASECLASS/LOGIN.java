package BASECLASS;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LOGIN {
	WebDriver dr;
	@FindBy(xpath="//*[@id='Email']")
	WebElement mailText;
	@FindBy(xpath="//*[@id='Password\']")
	WebElement pwdText;
	@FindBy(xpath="//*[@class='form-fields']/form/div[5]/input")
	WebElement loginbtn;
	@FindBy(xpath="/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")
	WebElement login;
	public LOGIN(WebDriver dr) {
		this.dr =dr;
		PageFactory.initElements(dr, this);	
	}
	public void login21()
	{
		login.click();
	}
	public void userlogin(String email,String pwd)
	{
		
	mailText.sendKeys(email);
	pwdText.sendKeys(pwd);
    loginbtn.click();
	}
	public String verifyTitle()
	{
		return dr.getTitle();
	}
}

