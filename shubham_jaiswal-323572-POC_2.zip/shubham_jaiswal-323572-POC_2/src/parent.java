
public class parent 
{
	String tc_id,flag,keyword,xpath,test_data;
	int steps;

}
